
class B
{



}

class A6 {

 B6  m11()
     
{
System.out.println("A6");

return new B6();


}

public static void main(String hathi[])
{
 
A6 obj  = new A6();

obj.m11();
}
}






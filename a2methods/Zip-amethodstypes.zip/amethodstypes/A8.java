
class B8
{



}

class A8 {

 B8  m11()
     
{
System.out.println("A7");

B8 objB8 = new B8();

return objB8;


}

public static void main(String hathi[])
{
 
A8 objA8  = new A8();

objA8.m11();


 
}
}
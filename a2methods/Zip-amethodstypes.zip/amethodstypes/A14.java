class A14  implements I
{

I  m11() 
{
System.out.println("m11 method call hua");

return new A14();
}

public static void main(String hathi[])

{
 A14 obj = new A14(); 

  obj.m11();



}

}


Interface I
{

}
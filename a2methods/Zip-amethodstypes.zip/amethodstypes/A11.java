/* return type hai interface type kaa  , hence ham interface I ko implement 

 karne waali class ka obect return karenge

 incompatible types: I cannot be converted to A11
  A11 store = obj.m11();
                     ^

*/


class A11  implements I
{

I  m11() 
{
System.out.println("m11 method call hua");
System.out.println("aur uski value ko hold krara store  me");
return new A11();
}

public static void main(String hathi[])

{
 A11 obj = new A11(); 

  A11 store = obj.m11();

System.out.println(store);

}

}

interface I
{
 
}